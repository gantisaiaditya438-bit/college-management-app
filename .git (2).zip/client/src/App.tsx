import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { AppLayout } from "@/components/layout/AppLayout";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/auth/LoginPage";
import StudentDashboard from "@/pages/student/StudentDashboard";
import FacultyDashboard from "@/pages/faculty/FacultyDashboard";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import PlacementPage from "@/pages/student/PlacementPage";
import AttendancePage from "@/pages/student/AttendancePage";

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/" component={() => <Redirect to="/login" />} />
        
        {/* Student Routes */}
        <Route path="/student" component={StudentDashboard} />
        <Route path="/student/courses" component={() => <div>My Courses Page (Coming Soon)</div>} />
        <Route path="/student/attendance" component={AttendancePage} />
        <Route path="/student/results" component={() => <div>Results Page (Coming Soon)</div>} />
        <Route path="/student/placements" component={PlacementPage} />

        {/* Faculty Routes */}
        <Route path="/faculty" component={FacultyDashboard} />
        <Route path="/faculty/students" component={() => <div>Student List Page (Coming Soon)</div>} />
        <Route path="/faculty/attendance" component={() => <div>Mark Attendance Page (Coming Soon)</div>} />

        {/* Admin Routes */}
        <Route path="/admin" component={AdminDashboard} />

        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Toaster />
        <Router />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
