import { createContext, useContext, useState, ReactNode } from "react";
import { useLocation } from "wouter";

export type UserRole = "student" | "faculty" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [, setLocation] = useLocation();

  const login = (role: UserRole) => {
    // Mock login logic
    let mockUser: User;
    
    switch (role) {
      case "student":
        mockUser = {
          id: "s123",
          name: "Alex Thompson",
          email: "alex.t@campus.edu",
          role: "student",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex"
        };
        setLocation("/student");
        break;
      case "faculty":
        mockUser = {
          id: "f456",
          name: "Dr. Sarah Miller",
          email: "s.miller@campus.edu",
          role: "faculty",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah"
        };
        setLocation("/faculty");
        break;
      case "admin":
        mockUser = {
          id: "a789",
          name: "Administrator",
          email: "admin@campus.edu",
          role: "admin",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Admin"
        };
        setLocation("/admin");
        break;
    }
    
    setUser(mockUser!);
  };

  const logout = () => {
    setUser(null);
    setLocation("/login");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
