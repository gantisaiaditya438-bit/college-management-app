import { StatCard } from "@/components/dashboard/StatCard";
import { Users, Shield, Activity, Server } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

const SYSTEM_ACTIVITY = [
  { name: "08:00", active: 120 },
  { name: "10:00", active: 450 },
  { name: "12:00", active: 380 },
  { name: "14:00", active: 520 },
  { name: "16:00", active: 200 },
  { name: "18:00", active: 80 },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold font-serif tracking-tight">System Administration</h1>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Users" 
          value="2,450" 
          icon={Users} 
          description="Students & Faculty"
          className="border-l-4 border-l-primary"
        />
        <StatCard 
          title="System Health" 
          value="99.9%" 
          icon={Activity} 
          description="All systems operational"
          className="border-l-4 border-l-green-500"
        />
        <StatCard 
          title="Active Sessions" 
          value="142" 
          icon={Server} 
          description="Currently online"
          className="border-l-4 border-l-purple-500"
        />
        <StatCard 
          title="Security Alerts" 
          value="0" 
          icon={Shield} 
          description="No threats detected"
          className="border-l-4 border-l-blue-500"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Peak Activity Times</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={SYSTEM_ACTIVITY}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <Tooltip 
                    cursor={{ fill: 'hsl(var(--muted)/0.2)' }}
                    contentStyle={{ 
                      borderRadius: 'var(--radius)', 
                      border: '1px solid hsl(var(--border))',
                      boxShadow: 'var(--shadow-sm)'
                    }}
                  />
                  <Bar 
                    dataKey="active" 
                    fill="hsl(var(--primary))" 
                    radius={[4, 4, 0, 0]} 
                    barSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent System Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b pb-2">
                <div className="flex flex-col">
                  <span className="text-sm font-medium">New User Registration</span>
                  <span className="text-xs text-muted-foreground">ID: 5251412050</span>
                </div>
                <span className="text-xs text-muted-foreground">2 mins ago</span>
              </div>
              <div className="flex items-center justify-between border-b pb-2">
                <div className="flex flex-col">
                  <span className="text-sm font-medium">Bulk Attendance Upload</span>
                  <span className="text-xs text-muted-foreground">By: Dr. Sarah Miller</span>
                </div>
                <span className="text-xs text-muted-foreground">15 mins ago</span>
              </div>
              <div className="flex items-center justify-between border-b pb-2">
                <div className="flex flex-col">
                  <span className="text-sm font-medium">Database Backup</span>
                  <span className="text-xs text-muted-foreground">Automated Task</span>
                </div>
                <span className="text-xs text-muted-foreground">1 hour ago</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
