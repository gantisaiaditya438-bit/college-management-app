import { StatCard } from "@/components/dashboard/StatCard";
import { Users, BookOpen, Calendar, FileCheck, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MOCK_STUDENTS } from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";

export default function FacultyDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold font-serif tracking-tight">Faculty Dashboard</h1>
        <div className="flex gap-2">
          <Button>
            <Calendar className="mr-2 h-4 w-4" />
            Mark Attendance
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Students" 
          value="124" 
          icon={Users} 
          description="Across 3 sections"
          className="border-l-4 border-l-primary"
        />
        <StatCard 
          title="Classes Today" 
          value="4" 
          icon={BookOpen} 
          description="Next: CS102 at 10 AM"
          className="border-l-4 border-l-secondary"
        />
        <StatCard 
          title="Pending Reviews" 
          value="12" 
          icon={FileCheck} 
          description="Assignment submissions"
          className="border-l-4 border-l-orange-400"
        />
        <StatCard 
          title="Avg Attendance" 
          value="78%" 
          icon={Calendar} 
          trend="down"
          trendValue="2%"
          className="border-l-4 border-l-red-500"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-1">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle>Student Attendance Overview</CardTitle>
            <div className="w-[200px]">
              <Input placeholder="Search student..." className="h-8" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50 transition-colors hover:bg-muted/50">
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Reg No</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Name</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Course</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Attendance %</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">CGPA</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {MOCK_STUDENTS.map((student) => (
                    <tr key={student.id} className="border-b transition-colors hover:bg-muted/50">
                      <td className="p-4 align-middle font-medium">{student.regNo}</td>
                      <td className="p-4 align-middle">{student.name}</td>
                      <td className="p-4 align-middle">{student.course}</td>
                      <td className="p-4 align-middle">
                        <div className="flex items-center gap-2">
                          <span className={student.attendance < 75 ? "text-red-600 font-bold" : ""}>
                            {student.attendance}%
                          </span>
                        </div>
                      </td>
                      <td className="p-4 align-middle">{student.cgpa}</td>
                      <td className="p-4 align-middle">
                        {student.attendance < 75 ? (
                          <Badge variant="destructive">Low Attendance</Badge>
                        ) : (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Good</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
