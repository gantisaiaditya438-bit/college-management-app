import { StatCard } from "@/components/dashboard/StatCard";
import { AttendanceChart } from "@/components/dashboard/AttendanceChart";
import { ATTENDANCE_STATS, MOCK_COURSES, MOCK_NOTIFICATIONS } from "@/lib/mock-data";
import { CalendarCheck, Trophy, Briefcase, Clock, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function StudentDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold font-serif tracking-tight">Student Dashboard</h1>
        <div className="text-sm text-muted-foreground">
          Academic Year: 2025-2026 | Semester: 1
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Overall Attendance" 
          value="82.4%" 
          icon={CalendarCheck} 
          trend="up" 
          trendValue="2.1%"
          className="border-l-4 border-l-primary"
        />
        <StatCard 
          title="Current CGPA" 
          value="8.5" 
          icon={Trophy} 
          description="Top 10% of class"
          className="border-l-4 border-l-secondary"
        />
        <StatCard 
          title="Active Courses" 
          value="6" 
          icon={Clock} 
          description="2 assignments due"
          className="border-l-4 border-l-blue-400"
        />
        <StatCard 
          title="Placement Drives" 
          value="3" 
          icon={Briefcase} 
          description="Eligible to apply"
          className="border-l-4 border-l-green-500"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-4">
          <AttendanceChart data={ATTENDANCE_STATS} />
        </div>
        <div className="col-span-3 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {MOCK_NOTIFICATIONS.map((notif) => (
                  <div key={notif.id} className="flex items-start gap-3 border-b border-border pb-3 last:border-0 last:pb-0">
                    <div className="mt-1">
                      <AlertCircle className="h-5 w-5 text-primary" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">{notif.title}</p>
                      <p className="text-xs text-muted-foreground">{notif.message}</p>
                      <p className="text-[10px] text-muted-foreground/70">{notif.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>My Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {MOCK_COURSES.map((course) => (
                <div key={course.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50">
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">{course.name}</span>
                    <span className="text-xs text-muted-foreground">{course.code} • {course.faculty}</span>
                  </div>
                  <Badge variant="outline" className="bg-background">{course.schedule}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
           <CardHeader>
            <CardTitle>Upcoming Deadlines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
               <div className="flex items-center justify-between">
                 <div className="flex flex-col">
                   <span className="font-medium text-sm">Data Structures Assignment 2</span>
                   <span className="text-xs text-muted-foreground">Due: Today, 11:59 PM</span>
                 </div>
                 <Badge variant="destructive">Urgent</Badge>
               </div>
               <div className="flex items-center justify-between">
                 <div className="flex flex-col">
                   <span className="font-medium text-sm">Physics Lab Record</span>
                   <span className="text-xs text-muted-foreground">Due: Tomorrow, 5:00 PM</span>
                 </div>
                 <Badge variant="secondary">Pending</Badge>
               </div>
               <div className="flex items-center justify-between">
                 <div className="flex flex-col">
                   <span className="font-medium text-sm">Calculus Quiz</span>
                   <span className="text-xs text-muted-foreground">Date: 12th Dec</span>
                 </div>
                 <Badge variant="outline">Scheduled</Badge>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
