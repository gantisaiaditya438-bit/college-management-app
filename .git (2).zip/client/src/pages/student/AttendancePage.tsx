import { MOCK_COURSES } from "@/lib/mock-data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function AttendancePage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-serif tracking-tight">Detailed Attendance</h1>
          <p className="text-muted-foreground mt-1">Track your attendance across all courses.</p>
        </div>
      </div>

      <div className="grid gap-6">
        {MOCK_COURSES.map((course, index) => {
          // Generate random attendance for demo
          const totalClasses = 45;
          const present = Math.floor(Math.random() * (totalClasses - 30) + 30); // Random between 30 and 45
          const percentage = Math.round((present / totalClasses) * 100);
          
          return (
            <Card key={course.id}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{course.name}</h3>
                    <p className="text-sm text-muted-foreground">{course.code} • {course.faculty}</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-2xl font-bold ${percentage < 75 ? 'text-destructive' : 'text-primary'}`}>
                      {percentage}%
                    </span>
                    <p className="text-xs text-muted-foreground">{present}/{totalClasses} Classes Attended</p>
                  </div>
                </div>
                <Progress value={percentage} className="h-2" />
                <div className="mt-4 flex gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-primary" />
                    Present: {present}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-muted" />
                    Absent: {totalClasses - present}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
