import { useAuth, UserRole } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, Users, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

export default function LoginPage() {
  const { login } = useAuth();

  const RoleCard = ({ role, title, icon: Icon, description }: { role: UserRole, title: string, icon: any, description: string }) => (
    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
      <Card 
        className="cursor-pointer hover:border-primary/50 transition-colors"
        onClick={() => login(role)}
      >
        <CardHeader>
          <div className="mb-2 h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <Icon className="h-6 w-6" />
          </div>
          <CardTitle className="text-xl">{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
      </Card>
    </motion.div>
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left side - Hero */}
      <div className="lg:w-1/2 bg-primary text-primary-foreground p-12 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-10 mix-blend-overlay"></div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-8">
            <GraduationCap className="h-8 w-8" />
            <h1 className="text-2xl font-serif font-bold">CampusConnect</h1>
          </div>
          <div className="max-w-md">
            <h2 className="text-5xl font-serif font-bold mb-6 leading-tight">
              Manage your academic journey with ease.
            </h2>
            <p className="text-lg opacity-90 leading-relaxed">
              A comprehensive platform for students, faculty, and administration to collaborate and succeed together.
            </p>
          </div>
        </div>
        <div className="relative z-10 text-sm opacity-70">
          © 2025 CampusConnect Inc.
        </div>
      </div>

      {/* Right side - Login Selection */}
      <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center bg-background">
        <div className="max-w-md mx-auto w-full space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight">Welcome back</h2>
            <p className="text-muted-foreground mt-2">Select your role to continue to the portal</p>
          </div>

          <div className="grid gap-4">
            <RoleCard 
              role="student" 
              title="Student Portal" 
              icon={GraduationCap}
              description="Access courses, attendance, results, and placements."
            />
            <RoleCard 
              role="faculty" 
              title="Faculty Portal" 
              icon={Users}
              description="Manage attendance, upload marks, and view class reports."
            />
            <RoleCard 
              role="admin" 
              title="Admin Portal" 
              icon={ShieldCheck}
              description="System configuration, user management, and global analytics."
            />
          </div>
        </div>
      </div>
    </div>
  );
}
