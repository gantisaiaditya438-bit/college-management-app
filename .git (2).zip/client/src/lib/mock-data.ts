import { startOfWeek, endOfWeek, eachDayOfInterval, format } from "date-fns";

// Types
export interface Student {
  id: string;
  name: string;
  regNo: string;
  course: string;
  semester: number;
  attendance: number; // percentage
  cgpa: number;
}

export interface Course {
  id: string;
  code: string;
  name: string;
  credits: number;
  faculty: string;
  schedule: string;
}

export interface AttendanceRecord {
  date: string;
  status: "present" | "absent" | "late";
  courseId: string;
}

export interface Placement {
  id: string;
  company: string;
  role: string;
  package: string; // LPA
  deadline: string;
  eligibility: string;
  logo?: string;
}

// Mock Data

export const MOCK_STUDENTS: Student[] = [
  { id: "1", name: "Alagara Sarath Kumar", regNo: "5251412001", course: "CSM(A)", semester: 1, attendance: 46.29, cgpa: 7.8 },
  { id: "2", name: "Allamraju Indira Madhu", regNo: "5251412002", course: "CSM(A)", semester: 1, attendance: 76.56, cgpa: 8.2 },
  { id: "3", name: "Aripaka Nagakusuma", regNo: "5251412003", course: "CSM(A)", semester: 1, attendance: 83.38, cgpa: 8.5 },
  { id: "4", name: "Bandaru Lakshmi Kalyani", regNo: "5251412004", course: "CSM(A)", semester: 1, attendance: 79.23, cgpa: 7.9 },
  { id: "5", name: "Bangaru Akhila", regNo: "5251412005", course: "CSM(A)", semester: 1, attendance: 78.34, cgpa: 8.1 },
  { id: "6", name: "Baratam Sameera", regNo: "5251412006", course: "CSM(A)", semester: 1, attendance: 46.29, cgpa: 6.5 },
  { id: "7", name: "Battula Himavanth", regNo: "5251412007", course: "CSM(A)", semester: 1, attendance: 50.64, cgpa: 6.8 },
  { id: "8", name: "Bikkina Sai Kavya Varshini", regNo: "5251412008", course: "CSM(A)", semester: 1, attendance: 85.16, cgpa: 8.9 },
  { id: "9", name: "Bobbara Durga Prasad", regNo: "5251412009", course: "CSM(A)", semester: 1, attendance: 91.99, cgpa: 9.2 },
  { id: "10", name: "Bokam Jagan", regNo: "5251412010", course: "CSM(A)", semester: 1, attendance: 73.57, cgpa: 7.5 },
  { id: "36", name: "Inti Charan Sai", regNo: "5251412036", course: "CSM(A)", semester: 1, attendance: 86.35, cgpa: 8.4 },
  { id: "37", name: "Irigineni Raghuvardhan", regNo: "5251412037", course: "CSM(A)", semester: 1, attendance: 94.07, cgpa: 9.1 },
  { id: "38", name: "Jakkampudi Anil", regNo: "5251412038", course: "CSM(A)", semester: 1, attendance: 77.74, cgpa: 7.6 },
  { id: "39", name: "Jakkireddy Sai Vikas Reddy", regNo: "5251412039", course: "CSM(A)", semester: 1, attendance: 83.68, cgpa: 8.2 },
  { id: "40", name: "Janni Dhiraj", regNo: "5251412040", course: "CSM(A)", semester: 1, attendance: 56.68, cgpa: 6.2 },
  { id: "41", name: "Jonnada Akhil", regNo: "5251412041", course: "CSM(A)", semester: 1, attendance: 95.85, cgpa: 9.3 },
  { id: "42", name: "Kagithala Rama Venkata Sai Vathsal Reddy", regNo: "5251412042", course: "CSM(A)", semester: 1, attendance: 83.68, cgpa: 8.1 },
  { id: "43", name: "Kalisipudi Rohit Sarma", regNo: "5251412043", course: "CSM(A)", semester: 1, attendance: 90.21, cgpa: 8.8 },
  { id: "44", name: "Kalla Venkata Shanmukha Priya", regNo: "5251412044", course: "CSM(A)", semester: 1, attendance: 81.90, cgpa: 8.0 },
  { id: "45", name: "Kamavarapu Keerthana", regNo: "5251412045", course: "CSM(A)", semester: 1, attendance: 94.07, cgpa: 9.0 },
  { id: "46", name: "Kandiboyina Harshith Ram", regNo: "5251412046", course: "CSM(A)", semester: 1, attendance: 81.60, cgpa: 7.9 },
  { id: "47", name: "Karakavalasa Rohitasva Sai Surya", regNo: "5251412047", course: "CSM(A)", semester: 1, attendance: 78.04, cgpa: 7.7 },
  { id: "48", name: "Karukundi Phani Kumar", regNo: "5251412048", course: "CSM(A)", semester: 1, attendance: 89.32, cgpa: 8.6 },
  { id: "49", name: "Ketha Saahiti", regNo: "5251412049", course: "CSM(A)", semester: 1, attendance: 83.09, cgpa: 8.3 },
  { id: "50", name: "Kilaparthi Bhagya Lakshmi", regNo: "5251412050", course: "CSM(A)", semester: 1, attendance: 88.72, cgpa: 8.5 },
  { id: "51", name: "Kodavati Purnesh", regNo: "5251412051", course: "CSM(A)", semester: 1, attendance: 78.64, cgpa: 7.8 },
  { id: "52", name: "Korepella Neelesh Sai", regNo: "5251412052", course: "CSM(A)", semester: 1, attendance: 77.15, cgpa: 7.5 },
  { id: "53", name: "Kurma Kundhana", regNo: "5251412053", course: "CSM(A)", semester: 1, attendance: 70.03, cgpa: 7.0 },
  { id: "54", name: "Lankada Venkata Srinivas", regNo: "5251412054", course: "CSM(A)", semester: 1, attendance: 56.97, cgpa: 6.3 },
  { id: "55", name: "Lingabathina Mohith Pramod", regNo: "5251412055", course: "CSM(A)", semester: 1, attendance: 69.73, cgpa: 6.9 },
  { id: "56", name: "Majji Praveena", regNo: "5251412056", course: "CSM(A)", semester: 1, attendance: 80.94, cgpa: 8.0 },
  { id: "57", name: "Mannam Varun Teja", regNo: "5251412057", course: "CSM(A)", semester: 1, attendance: 77.15, cgpa: 7.6 },
  { id: "58", name: "Maradana Akhila", regNo: "5251412058", course: "CSM(A)", semester: 1, attendance: 78.04, cgpa: 7.8 },
  { id: "59", name: "Maroju Doni Sampath Vinayak", regNo: "5251412059", course: "CSM(A)", semester: 1, attendance: 62.02, cgpa: 6.5 },
  { id: "60", name: "Pasupulati Sai Tarun", regNo: "5251412060", course: "CSM(A)", semester: 1, attendance: 10.48, cgpa: 4.5 },
  { id: "61", name: "Vadamodula Pralok", regNo: "5251412061", course: "CSM(A)", semester: 1, attendance: 51.04, cgpa: 5.8 },
];

export const MOCK_COURSES: Course[] = [
  { id: "c1", code: "CS101", name: "Introduction to Programming", credits: 4, faculty: "Dr. Smith", schedule: "Mon, Wed 10:00 AM" },
  { id: "c2", code: "MA101", name: "Calculus I", credits: 3, faculty: "Prof. Johnson", schedule: "Tue, Thu 09:00 AM" },
  { id: "c3", code: "PH101", name: "Physics I", credits: 4, faculty: "Dr. Brown", schedule: "Mon, Wed 02:00 PM" },
  { id: "c4", code: "CS102", name: "Data Structures", credits: 4, faculty: "Dr. Smith", schedule: "Fri 10:00 AM" },
];

export const MOCK_PLACEMENTS: Placement[] = [
  { id: "p1", company: "Google", role: "Software Engineer", package: "24 LPA", deadline: "2025-12-15", eligibility: "CGPA > 8.0, No backlogs", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/768px-Google_%22G%22_logo.svg.png" },
  { id: "p2", company: "Microsoft", role: "SDE I", package: "22 LPA", deadline: "2025-12-20", eligibility: "CGPA > 7.5", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/2048px-Microsoft_logo.svg.png" },
  { id: "p3", company: "Amazon", role: "Cloud Support Associate", package: "18 LPA", deadline: "2026-01-05", eligibility: "Any Graduate", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png" },
  { id: "p4", company: "TCS", role: "System Engineer", package: "7 LPA", deadline: "2026-01-15", eligibility: "60% throughout academics" },
];

export const MOCK_NOTIFICATIONS = [
  { id: "n1", title: "Attendance Warning", message: "Your attendance in CS101 is below 75%.", type: "alert", date: "2 hours ago" },
  { id: "n2", title: "Exam Results Out", message: "Semester 1 results have been published.", type: "info", date: "1 day ago" },
  { id: "n3", title: "Google Placement Drive", message: "Applications for Google open tomorrow.", type: "success", date: "2 days ago" },
];

export const ATTENDANCE_STATS = [
  { name: "Mon", present: 85 },
  { name: "Tue", present: 92 },
  { name: "Wed", present: 78 },
  { name: "Thu", present: 88 },
  { name: "Fri", present: 70 },
];

export const EXAM_PERFORMANCE = [
  { subject: "Programming", score: 85, avg: 72 },
  { subject: "Calculus", score: 78, avg: 65 },
  { subject: "Physics", score: 92, avg: 70 },
  { subject: "English", score: 88, avg: 80 },
  { subject: "Electronics", score: 75, avg: 68 },
];
