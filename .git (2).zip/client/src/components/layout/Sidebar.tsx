import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  GraduationCap, 
  Users, 
  CalendarCheck, 
  FileText, 
  Briefcase, 
  Settings, 
  LogOut,
  LucideIcon
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

interface SidebarLink {
  href: string;
  label: string;
  icon: LucideIcon;
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const studentLinks: SidebarLink[] = [
    { href: "/student", label: "Dashboard", icon: LayoutDashboard },
    { href: "/student/courses", label: "My Courses", icon: GraduationCap },
    { href: "/student/attendance", label: "Attendance", icon: CalendarCheck },
    { href: "/student/results", label: "Results", icon: FileText },
    { href: "/student/placements", label: "Placements", icon: Briefcase },
  ];

  const facultyLinks: SidebarLink[] = [
    { href: "/faculty", label: "Dashboard", icon: LayoutDashboard },
    { href: "/faculty/students", label: "Student List", icon: Users },
    { href: "/faculty/attendance", label: "Mark Attendance", icon: CalendarCheck },
    { href: "/faculty/marks", label: "Upload Marks", icon: FileText },
  ];

  const adminLinks: SidebarLink[] = [
    { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { href: "/admin/users", label: "User Management", icon: Users },
    { href: "/admin/courses", label: "Course Management", icon: GraduationCap },
    { href: "/admin/settings", label: "Settings", icon: Settings },
  ];

  let links: SidebarLink[] = [];
  if (user?.role === "student") links = studentLinks;
  else if (user?.role === "faculty") links = facultyLinks;
  else if (user?.role === "admin") links = adminLinks;

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r bg-sidebar text-sidebar-foreground transition-transform hidden md:block">
      <div className="flex h-full flex-col">
        <div className="flex h-16 items-center border-b border-sidebar-border px-6">
          <GraduationCap className="mr-2 h-6 w-6 text-sidebar-primary" />
          <span className="text-lg font-bold font-serif tracking-tight">CampusConnect</span>
        </div>

        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-3">
            {links.map((link) => {
              const Icon = link.icon;
              const isActive = location === link.href;
              return (
                <Link key={link.href} href={link.href}>
                  <a className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors cursor-pointer",
                    isActive 
                      ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}>
                    <Icon className="mr-3 h-4 w-4" />
                    {link.label}
                  </a>
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="border-t border-sidebar-border p-4">
          <div className="flex items-center gap-3 mb-4 px-2">
            <img 
              src={user?.avatar} 
              alt={user?.name} 
              className="h-8 w-8 rounded-full bg-sidebar-primary/20"
            />
            <div className="flex flex-col overflow-hidden">
              <span className="truncate text-sm font-medium">{user?.name}</span>
              <span className="truncate text-xs text-sidebar-foreground/70 capitalize">{user?.role}</span>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border-sidebar-border"
            onClick={logout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </div>
    </aside>
  );
}
